package test;

import org.newdawn.slick.*;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;

public class WorldMap extends BasicGameState {

	public WorldMap(int worldmap) {
	}

	public void init(GameContainer gc, StateBasedGame sbg)
			throws SlickException {
	}

	public void render(GameContainer gc, StateBasedGame sbg, Graphics g)
			throws SlickException {
	}

	public void update(GameContainer gc, StateBasedGame sbg, int delta)
			throws SlickException {	
	}

	public int getID() {
		return 1;
	}
}
