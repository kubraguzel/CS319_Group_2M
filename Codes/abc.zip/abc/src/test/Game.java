package test;
import org.newdawn.slick.*;
import org.newdawn.slick.state.*;

public class Game extends StateBasedGame{
	public static final String gameName="Survival in Bilkent";
	public static final int startMenu=0;
	public static final int worldMap=1;
	
	public Game(String gameName){
		super(gameName);
		this.addState(new MainMenu(startMenu));
		this.addState(new WorldMap(worldMap));
	}
	public void initStatesList(GameContainer gc) throws SlickException{
		this.getState(startMenu).init(gc,this);
		this.getState(worldMap).init(gc,this);
		this.enterState(startMenu);
	}
	public static void main(String[] args) throws SlickException{
		AppGameContainer agc;
		try{
			agc= new AppGameContainer(new Game(gameName));
			agc.setDisplayMode(700, 700, false);
			agc.start();
		}catch(SlickException e){
			e.printStackTrace();	
		}
	}
	
}
